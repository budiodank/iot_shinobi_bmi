<?php 
	$AccessTokenUri = "https://flexiot.xl.co.id/api/applicationmgt/authenticate";
 
  $apiKey = "ZGVWQklXM011NVZfNEM3ZTJXX3BfcEphS3EwYTpmcTQydmZLNm15R3ZqTVF3S2EyNkRLTUJkcDRh"; 
  $options = array(
    'http' => array(
        'header'  => "X-Secret: ".$apiKey."\r\n" .
        "content-length: 0\r\n",
        'method'  => 'GET',
    ),
  );

  $context  = stream_context_create($options);

  //get the Access Token
  $access_token = file_get_contents($AccessTokenUri, false, $context);

  if (!$access_token) {
    throw new Exception("Problem with $AccessTokenUri, $php_errormsg");
  }
    else{

$aa = json_decode($access_token,true);
$bearer = $aa['access_token'];
   echo "Access Token: ". $bearer. "<br>";

    $ttsServiceUri = "https://flexiot.xl.co.id/api/usermgt/v1/authenticate";
  $data  =  json_encode(array("username" => "ficed123@gmail.com", "password" => "dzailfc17"));


   echo " data: <pre>". print_r($data) . "</pre><br>";
   $options = array(
    'http' => array(
        'header'  => "Content-type: application/json\r\n" . 
                    "Authorization: "."Bearer ".$bearer."\r\n"   ,
        'method'  => 'POST',
        'content' => $data,
        ),
    );

    $context  = stream_context_create($options);

    // get the wave data
    $result = file_get_contents($ttsServiceUri, false, $context);
    if (!$result) {
        throw new Exception("Problem with $ttsServiceUri, $php_errormsg");
      }
    else{ 
    $x = json_decode($result,true);
    $iotjwt = $x['X-IoT-JWT'];   

    echo "JWT : ".$iotjwt;
    // devices
   $dev = "https://flexiot.xl.co.id/api/userdevicemgt/v1/devices";
   $options1 = array(
    'http' => array(
        'header'  => "Content-type: application/json\r\n" . 
                    "Authorization: "."Bearer ".$bearer."\r\n" . 
                    "X-IoT-JWT: ".$iotjwt."\r\n"  , 
        'method'  => 'GET' 
        ),
    );
    $context1  = stream_context_create($options1);
    // get the wave data
    $result1 = file_get_contents($dev, false, $context1);
    if (!$result1) {
        throw new Exception("Problem with $ttsServiceUri, $php_errormsg");
      }
    else{ 

    print_r(json_encode($result1));
    $xx = json_decode($result1,true);
    echo "<pre>";
    print_r($xx);
    echo "</pre>";
    // Devices Last Status
    $idd = $xx[1]['id'];
    echo "device ID : ".$idd;
      $dev2 = "https://flexiot.xl.co.id/api/userdevicemgt/v1/devices/".$idd."/status";
   $options2 = array(
    'http' => array(
        'header'  => "Content-type: application/json\r\n" . 
                    "Authorization: "."Bearer ".$bearer."\r\n" . 
                    "X-IoT-JWT: ".$iotjwt."\r\n" . 
                    "deviceId: ".$idd."\r\n"  , 
        'method'  => 'GET' 
        ),
    );
    $context2  = stream_context_create($options2);
    // get the wave data
    $result2 = file_get_contents($dev2, false, $context2);
    if (!$result2) {
        throw new Exception("Problem with $ttsServiceUri, $php_errormsg");
      }
    else{ 
    	print_r($result2);

    }

    }
  }
}
 ?>