<?php

class Config
	{
		protected $host		= 'localhost';
		protected $dbname 	= 'iotshinobi';
		protected $user	 	= 'root';
		protected $password	= 'flamingo';

		public function connectionKey()
		{
			$mysqli = mysqli_connect($this->host,$this->user,$this->password);
			$mysqli->select_db($this->dbname);

			return $mysqli;
		}

		public function check()
		{
			$check = "Ea";
			return $check;
		}

		public function closeConnection()
		{
			$mysqli = null;
		}

		public function getDriver($id)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT * FROM driver WHERE id_driver = '$id'");

			return $query;
		}

		public function getAccelero($driverId, $shippingId)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT * FROM acelerometer WHERE driver_id = '$driverId' AND shipping_id ='$shippingId'");

			return $query;
		}

		/*public function getAcceleroAvg($driverId, $shippingId)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT AVG(goyangan) FROM acelerometer WHERE driver_id = '$driverId' AND shipping_id ='$shippingId'");

			if ($query) {
				echo $query;
			}

			return $query;
		}*/

		public function getGps($driverId)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT * FROM tracking WHERE driver_id = '$driverId'");

			return $query;
		}

		public function getShipping($driverId)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT * FROM shipping WHERE driver_id = '$driverId'");

			return $query;
		}

		public function getCustomer($customerId)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("SELECT * FROM customer WHERE customer_id = '$customerId'");

			return $query;
		}

		public function addCustomer($customerId, $nama, $alamat, $kota, $negara, $kode_pos, $tgl_lahir, $jk, $no_telp, $username, $password, $email)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("INSERT INTO customer SET customer_id = '$customerId', nama = '$nama', alamat = '$alamat', kota = '$kota', negara = '$negara', kode_pos = '$kode_pos', tgl_lahir = '$tgl_lahir', jenis_kelamin = '$jk', no_telp = '$no_telp', username = '$username', password = '$password', email = '$email';");

			if ($query) {
				echo "<script>alert('Data Sudah Masuk')</script>";
			}

			return $query;
		}

		public function addTracking($longitude, $latitude, $kecepatan, $driverId, $time)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("INSERT INTO tracking SET longitude = '$longitude', latitude = '$latitude', kecepatan = '$kecepatan', driver_id = $driverId, time = '$time';");

			return $query;
		}

		public function addAccelerometer($shippingId, $driverId, $goyangan, $time)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("INSERT INTO acelerometer SET shipping_id = '$shippingId', driver_id = $driverId, goyangan = '$goyangan', time = '$time';");

			return $query;
		}

		/*public function addDriver($driverId, $nama, $alamat, $kota, $kode_pos, $tgl_lahir, $jk, $no_telp, $username, $password, $email)
		{
			$callConn = $this->connectionKey();

			$query = $callConn->query("INSERT INTO driver (driver_id, nama, alamat, kota, kode_pos, tgl_lahir, jenis_kelamin, no_telp, username, password, email) VALUES ('$driverId', '$nama', '$alamat', '$kota', '$kode_pos', '$tgl_lahir', '$jenis_kelamin', '$no_telp', '$username', '$password', '$email')");

			if ($query) {
				echo "<script>alert('Data Sudah Masuk')</script>";
			}

			return $query;
		}*/

	}

	   
?>