<?php

	if(isset($_POST['submit']))
	{
		$username 	= $_POST['username'];
		$password	= md5($_POST['password']);
		$email		= $_POST['email'];
		$nik		= $_POST['nik'];
		$nama 		= $_POST['nama'];
		$tgl_lahir 	= $_POST['tgl_lahir'];
		$no_telp	= $_POST['no_telp'];
		$jenkel 	= $_POST['jenkel'];
		$alamat 	= $_POST['alamat'];
		$kota 		= $_POST['kota'];
		$negara	 	= $_POST['negara'];
		$kode_pos	= $_POST['kode_pos'];

		if($nik != "" && $username != "" && $password != "" && $email != "" && $nama != "" && $tgl_lahir != "" && $no_telp != "" && $jenkel != "" && $alamat != "" && $kota != "" && $negara != "" && $kode_pos != "")
		{
			$update = $config->addCustomer($nik, $nama, $alamat, $kota, $negara, $kode_pos, $tgl_lahir, $jenkel, $no_telp, $username, $password, $email);
			if ($update) 
			{
				header("location:index.php?page=new_customer");
			}
		}
		else 
		{
			echo "Isi Semua Field!!!";
		}
	}
 ?>