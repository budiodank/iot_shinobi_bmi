<?php 	
	require_once "../include/config.php";
 	$config = new Config();
 	date_default_timezone_set('Asia/Jakarta');

    $url_kecepatan = 'https://io.adafruit.com/api/v2/NUR_SOHIT17/feeds/kecepatan';
    $data_kecepatan = file_get_contents($url_kecepatan);
    $kecepatan = json_decode($data_kecepatan, true);

    $url_longitude = 'https://io.adafruit.com/api/v2/NUR_SOHIT17/feeds/longi';
    $data_longitude = file_get_contents($url_longitude);
    $longitude = json_decode($data_longitude, true);

    $url_latitude = 'https://io.adafruit.com/api/v2/NUR_SOHIT17/feeds/lati';
    $data_latitude = file_get_contents($url_latitude);
    $latitude = json_decode($data_latitude, true);

    /*echo $kecepatan['last_value']."<br />";
    echo $latitude['last_value']."<br />";
    echo $longitude['last_value']."<br />";*/
    $kec = $kecepatan['last_value'];
    $lat = $latitude['last_value'];
    $long = $longitude['last_value'];

    if ($kec != "" && $lat != "" && $long != "") {
    	$driverId = 12345678;
    	$time = date("Y-m-d H:i:s");

    	$add = $config->addTracking($long, $lat, $kec, $driverId, $time);

    	if ($add) {
    		echo "Berhasil Masuk";
    	}
    } else {
    	echo "Data tidak ada";
    }

    $url_mpu = 'https://io.adafruit.com/api/v2/NUR_SOHIT17/feeds/mpu';
    $data_mpu = file_get_contents($url_mpu);
    $mpu = json_decode($data_mpu, true);

    $mpu = $mpu['last_value'];

    if ($mpu != "") {
    	$driverId = 12345678;
    	$shippingId = 1;
    	$time = date("Y-m-d H:i:s");

    	$add = $config->addAccelerometer($shippingId, $driverId, $mpu, $time);

    	if ($add) {
    		echo "Data MPU Berhasil Masuk";
    	}
    } else {
    	echo "Data tidak ada";
    }

?>