<?php 
	require_once "../include/config.php";
  	$config = new Config();

  	$callConn = $config->connectionKey();

	if ($callConn) {

		$no = 1;

		$return_arr = array();

		foreach ($config->getHeight("all") as $height => $value) {
			$myObj['no'] = $no;
			$myObj['height'] = $value['height'];
        	/*echo $no.". ".$value['height']."<br />";
        	$no++;
        	echo count($height);*/
        	array_push($return_arr,$myObj);
        	$no += 1;
     	 }

     	$myJSON = json_encode($return_arr);

		echo $myJSON;

		/*echo array_sum($value['height']);
		echo count($value);*/
		
	} else {
		echo "Not Connect";
	}

    //$average = $callConn->query("SELECT AVG(goyangan) FROM acelerometer WHERE driver_id = '$driverId' AND shipping_id ='$shippingId'");
 ?>