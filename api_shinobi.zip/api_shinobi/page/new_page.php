<?php 

  require_once "include/config.php";
  include "include/api/php";
  $config = new Config();
  date_default_timezone_set('Asia/Jakarta');

	if(!$_GET['page']){
		echo '<script>document.location="?page=dashboard"</script>';
	}

    $base = $_SERVER['PHP_SELF'];
    $ambil =   file_get_contents($base."/shinobi/include/api.php?id=$dd[id]"); 
    $xx2 = json_decode($ambil,true); 

    $kec = $xx2[0]['value'];
    $lat = $xx2[1]['value'];
    $long = $xx2[3]['value'];
    $mpu = $xx2[2]['value'];

    if ($kec != "" && $lat != "" && $long != "") {
      $driverId = 12345678;
      $time = date("Y-m-d H:i:s");

      $add = $config->addTracking($long, $lat, $kec, $driverId, $time);

      if ($add) {
        //echo "Berhasil Masuk";
      }
    } else {
      //echo "Data tidak ada";
    }

    if ($mpu != "") {
      $driverId = 12345678;
      $shippingId = 1;
      $time = date("Y-m-d H:i:s");

      $add = $config->addAccelerometer($shippingId, $driverId, $mpu, $time);

      if ($add) {
        //echo "Data MPU Berhasil Masuk";
      }
    } else {
      //echo "Data tidak ada";
    }

 ?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>IOT Shinobi - <?php 
    if ($_GET['page'] == 'dashboard') {
      $keterangan = 'Dashboard';
    } else if ($_GET['page'] == 'driver')
    {
      $keterangan = 'Driver';
    } else if ($_GET['page'] == 'gps')
    {
      $keterangan = 'GPS';
    } else if ($_GET['page'] == 'accelerometer')
    {
      $keterangan = 'Accelerometer';
    } else if ($_GET['page'] == 'shipping')
    {
      $keterangan = 'Shipping';
    } else
    {
      $keterangan = '';
    }
    echo $keterangan;
  ?></title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="./assets/vendor/jquery/jquery3_.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
</head>

<body>
  <!-- Sidenav -->
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="./index.php">
        <h3>IOT Shinobi</h3>
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="./assets/img/theme/team-1-800x800.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="./examples/profile.html" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>My profile</span>
            </a>
            <a href="./examples/profile.html" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="./examples/profile.html" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Activity</span>
            </a>
            <a href="./examples/profile.html" class="dropdown-item">
              <i class="ni ni-support-16"></i>
              <span>Support</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#!" class="dropdown-item">
              <i class="ni ni-user-run"></i>
              <span>Logout</span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="./index.php">
                <img src="./assets/img/theme/blue.jpg">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        
        <?php 
          foreach ($config->getDriver('12345678') as $data_driver) {
            $data_driver['nama'];
            $data_driver['no_plat'];
          }
         ?>
        <!-- Navigation -->
        <div class="col-xl-8">
            <h2 class="mb-0">Driver</h3>
        </div>
        <hr style="border-color: #5603ad">
        <div class="p-3">
          <img src="./assets/img/theme/vue.jpg" alt="John Doe" class="mr-3 rounded-circle" style="width:100px;">
          <h4><?php echo $data_driver['nama']; ?></h4>
          <h4><?php echo $data_driver['no_plat']; ?></h4>
        </div>
        <hr>
        <?php 
          foreach ($config->getShipping('12345678') as $data_shipping) {
            $data_shipping['jenis'];
            $data_shipping['nama_brg'];
            $data_shipping['pengirim'];
            $data_shipping['penerima'];
            $data_shipping['status'];
          }
         ?>
        <div class="col-xl-8">
            <h2 class="mb-0">Shipping</h3>
        </div>
        <hr style="border-color: #5603ad">
         <div class="p-3">
          <p style="font-weight: bold;">1271110101</p>
          <h4><?php echo $data_shipping['jenis']; ?></h4>
          <h4><?php echo $data_shipping['nama_brg']; ?></h4>
          <h4><?php echo $data_shipping['pengirim']; ?></h4>
          <h4><?php echo $data_shipping['penerima']; ?></h4>
          <h4><?php echo $data_shipping['status']; ?></h4>
        </div>
        <hr>
        <!-- Divider -->
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="./index.php"><?php echo $keterangan; ?></a>

        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="./assets/img/theme/vue.jpg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span class="mb-0 text-sm  font-weight-bold">IOT Shinobi</span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
              <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome!</h6>
              </div>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>My profile</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-settings-gear-65"></i>
                <span>Settings</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-calendar-grid-58"></i>
                <span>Activity</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-support-16"></i>
                <span>Support</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#!" class="dropdown-item">
                <i class="ni ni-user-run"></i>
                <span>Logout</span>
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- start mainbar -->
			<?php include "include/paging.php"; ?>
		<!-- end mainbar -->
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2018 <a href="http://iotshinobi.000webhostapp.com" class="font-weight-bold ml-1" target="_blank">IOT Shinobi</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="http://iotshinobi.000webhostapp.com" class="nav-link" target="_blank">IOT Shinobi</a>
              </li>
              <li class="nav-item">
                <a href="http://iotshinobi.000webhostapp.com/about" class="nav-link" target="_blank">About Us</a>
              </li>
              <li class="nav-item">
                <a href="http://iotshinobi.000webhostapp.com/blog" class="nav-link" target="_blank">Blog</a>
              </li>
              <li class="nav-item">
                <a href="https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md" class="nav-link" target="_blank">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <script src="./assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmdKpqViAT9Q0OCxtYhTFjg20FNUNcfeo&callback=myMap"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.0.0"></script>
  <script type="text/javascript">
    <?php 
      $driverId = '12345678';
      $shippingId = '1';
     ?>
    var speedCanvas = document.getElementById("acceleroChart");

    //Chart.defaults.global.defaultFontFamily = "Lato";
    //Chart.defaults.global.defaultFontSize = 18;

    var speedData = {
      labels: [ <?php 
      foreach ($config->getAccelero($driverId, $shippingId) as $accelero) {
        $time = explode(" ", $accelero["time"]);
        echo '"' . $time[1] . '",';
      }
      ?>
      ],
      datasets: [{
        label: "Getaran",
        data: [
      //  Fungsi AJAX   
             $.ajax({
    type : "GET",
    data : "",
    url : "ajax.php", // Mengakses query pada tabel
    success : function(result){  // Menyimpan parameter url pada result
      var hasilDtt = JSON.parse(result);  // Memanggil result dengan json
      var dataHandler = $("#acceleroChart");  // Pemanggilan id muat-data-disini
          
      $.each(hasilDtt, function(key,val){  // Menampung hasilDtt dalam variable val
        print_f(val.goyangan);
          
        });
      }
    });
        ],
      }]
    };

    var chartOptions = {
      legend: {
        display: true,
        position: 'top',
        labels: {
          boxWidth: 80,
          fontColor: 'white'
        }
      }
    };

    var lineChart = new Chart(speedCanvas, {
      type: 'line',
      data: speedData,
      options: chartOptions
    });

    function acceleroChart() {
      location.reload('index.php?page=dashboard');
    }

    //$(document).ready(function() {
     /* var auto_refresh = setInterval(
      function () {
        $('#acceleroChart').reload('index.php?page=dashboard');
      }, 20000); // refresh setiap 1500 milliseconds*/
    //});
  </script>
  
    <script>
      function myMap() {
        var peta = new google.maps.Map(document.getElementById("map-canvas"), propertiPeta);
  
        var propertiPeta = {
          center:new google.maps.LatLng("<?php echo $gps['latitude']; ?>","<?php echo $gps['longitude']; ?>"),
          zoom:5,
          mapTypeId:google.maps.MapTypeId.ROADMAP
        };

        // membuat Marker
        var marker=new google.maps.Marker({
          position: new google.maps.LatLng(<?php echo $gps['latitude']; ?>, <?php echo $gps['longitude']; ?>),
          map: peta,
          icon: "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png"
        });

      }

      // event jendela di-load  
    //google.maps.event.addDomListener(window, 'load', initialize);
    </script>
</body>

</html>